#!/bin/bash
########################################################################
SELFCOPIES=${1:-0}
TRIGGERCOPIES=${2:-0}
########################################################################
if [ -f /usr/share/firstboot/modules/additional_cds.py ] ; then
  rm -f /usr/share/firstboot/modules/additional_cds.py*
fi

if [ -f /usr/share/firstboot/modules/rhn_register.py ] ; then
  rm -f /usr/share/firstboot/modules/rhn_register.py*
fi

