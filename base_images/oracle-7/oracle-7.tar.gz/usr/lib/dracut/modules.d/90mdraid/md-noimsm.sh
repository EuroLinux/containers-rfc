#!/bin/sh
# -*- mode: shell-script; indent-tabs-mode: nil; sh-basic-offset: 4; -*-
# ex: ts=8 sw=4 sts=4 et filetype=sh
info "rd.md.imsm=0: no MD RAID for imsm/isw raids"
udevproperty rd_NO_MDIMSM=1
